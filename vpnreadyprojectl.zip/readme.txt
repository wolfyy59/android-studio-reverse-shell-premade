u can use this project to edit it via cursor AI and android studio  its a ( kotlin project)
and get persistant reverse shell using netcat